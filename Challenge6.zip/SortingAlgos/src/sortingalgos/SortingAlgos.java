/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingalgos;

import java.util.Random;

/**
 *
 * @author 6306841
 * due date: 3/28/22
 * Description: The importance of this challenge is to understand and see how sorting algorithms work, with this
 * we can see time difference between them all.
 */
public class SortingAlgos {

    public static int[] myOriginalUnsortedArray1;
    public static int[] myCopyUnsortedArray2;
    public static long bubbleSortDuration, quickSortDuration, selectionSortDuration, insertionSortDuration, mergeSortDuration;
 
    
    /*
    Description:Our driver method that allows us to print other methods and see our work in progress.
    no throws, parameters or returns.
    */
    public static void main(String[] args) {
        
//Proof of Concept - that all sorting algorithms work as intended: 
        
        myOriginalUnsortedArray1 = generateRanNums(10);
        
       
        
//        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
//        quickSort(myCopyUnsortedArray2);  //Extra Credit!
//        
//        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
//        mergeSort(myCopyUnsortedArray2);  //Extra Credit!
        
        System.out.println("Selection Sort");
        myCopyUnsortedArray2 = new int[myOriginalUnsortedArray1.length];                
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        System.out.println("Before Selection Sort: ");
        printArray(myCopyUnsortedArray2);
        
        selectionSort(myCopyUnsortedArray2);
        System.out.println( );
        
        System.out.println("After Selection Sort: ");
        
        printArray(myCopyUnsortedArray2);
        System.out.println();
        
        System.out.println("Insertion Sort");
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        System.out.println("Before Insertion Sort: ");
        printArray(myCopyUnsortedArray2);
        
        insertionSort(myCopyUnsortedArray2);
        System.out.println();
        
        System.out.println("After Insertion Sort: ");
        printArray(myCopyUnsortedArray2);

        System.out.println("Bubble Sort:");
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        System.out.println("Before Bubble Sort: ");
        printArray(myCopyUnsortedArray2);
        
        bubbleSort(myCopyUnsortedArray2);
        System.out.println();
        System.out.println("After Bubble Sort: ");
        printArray(myCopyUnsortedArray2);
        compareSortTimes();
        System.out.println();
        
        
//******Actual Challenge:
        myOriginalUnsortedArray1 = generateRanNums(20000);
        
//        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
//        quickSort(myCopyUnsortedArray2);  //Extra Credit!
//        
//        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
//        mergeSort(myCopyUnsortedArray2);  //Extra Credit!

        System.out.println("Selection Sort with 20000 elements:");
        myCopyUnsortedArray2 = new int[myOriginalUnsortedArray1.length]; 
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        selectionSort(myCopyUnsortedArray2);
        
        System.out.println();
        
         System.out.println("Insertion Sort with 20000 elements:");
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        insertionSort(myCopyUnsortedArray2);
        
        System.out.println();
        
         System.out.println("Bubble Sort with 20000 elements:");
        copyRanNums(myOriginalUnsortedArray1, myCopyUnsortedArray2);
        bubbleSort(myCopyUnsortedArray2);
        
        System.out.println();
        
        compareSortTimes();
    }
    
    /*
   Description: This method actually loops and then prints our array.
    no throws, parameter, returns.
    */
    public static void printArray(int[] anArray)
    {
        //for-loop to print array
        for (int i= 0; i < anArray.length;i++)
        { 
            System.out.println(anArray[i] + " ");
        }
        System.out.println("");
    }
    
    /*
    Description: Method that allows us to create a random number generator, for our array two varying from 10 elements
    and another up to 20000 elements
    
    no throws, parameters is int num,  only returns anArray.
    */
    public static int[] generateRanNums(int num)
    {
        
         int [] anArray;
         int aNum;
        
         //1. Using Random class, generate in a for-loop 20K numbers in the range of 1 to 5000
         Random myRan = new Random();
        
        if (num <= 10)
        {
            //create a 10-element array
            anArray = new int [10];
 
            for (int i = 0; i < 10;i++)
            {
               
                aNum = myRan.nextInt(100)+1;
                anArray [i] = aNum;
            }
            
        }
        
            else
               {
                    //create a 20,000 - element array
                    anArray = new int [20000];
                   //for-loop for generating 20,000 numbers between 1 & 5000

                    for (int i = 0; i < 20000 ; i++)
                    {
                        aNum =  myRan.nextInt(5000)+1;

               }
            
               }
           
        return anArray;
        
    }
    
    /*
    Description:This method copies the original array and it allows us to actually see the numbers in our array.
    no throws, parameters, returns.
    */
    public static void copyRanNums(int[] fromArray, int[] toArray)
    {
        
        //Use a for-loop,
        //  access the original array at indx i
        //  move the value to copy array at index i
       int length = fromArray.length;
       for (int i = 0; i < length;i++)
       {
        toArray[i] = fromArray[i];   
       }
        
          
        
        
    }
    
    /*
    Description:The selectionSort method allows us to sort in a way where the algorithm gets a value and compares it to the largest number
    and when it finds sed value itll swap places until it is sorted. This method as well displays its sort time.
    no throws, int [] anArray parameter and no returns
    */
    public static void selectionSort(int[] anArray)
    {
        //1.  create a long variable  called startSort, and another one called endSort
        //2.  assign  System.nanoTime()  to startSort
        //3.  copy the sorting algorithm from PowerPoint 
        //4.  after sort is over, assign System.nanoTime() to endSort
        //5.  Calculate selectionSortDuration = endSort - startSort
       
        long startSort =  System.nanoTime();
       
        for (int last = anArray.length -1; last >= 1; last --)
            {
             int maxIndex = 0;
             
             for (int index = 1; index <= last; index++)
             {
                 if (anArray[index] > anArray[maxIndex]) 
                 {
                      maxIndex = index;
                 }
                    
             }
            
            int temp = anArray[maxIndex];
            anArray[maxIndex] = anArray[last];
            anArray[last] = temp;   

             
            }
              long endSort = System.nanoTime();  
              selectionSortDuration = endSort - startSort;
              System.out.println("NANOSECOND START: " + startSort);
              System.out.println("NANOSECOND END: " + endSort);
              System.out.println("This took " + selectionSortDuration + " nanoseconds");

          }
        
    
    /*
    Description:The insertion sort method allows us to create a sorting algorithm in a way that it individually inserts the element value in its correct spot
    its a faster algorithm than the other two. This method as well displays its sort time.
    no throws, int[] anArray parameter and no returns
    
    
    
    */
    public static void insertionSort(int[] anArray)
    {
        //1.  create a long variable  called startSort, and another one called endSort
        //2.  assign  System.nanoTime()  to startSort
        //3.  copy the sorting algorithm from PowerPoint 
        //4.  after sort is over, assign System.nanoTime() to endSort
        //5.  Calculate selectionSortDuration = endSort - startSort

        long startSort = System.nanoTime();
       
        int index;
        int scan;
        
       
       for (index = 1; index <= anArray.length -1; index ++)
       {
           
            int unSortedValue = anArray[index];
            scan = index;
            while (scan > 0 && anArray[scan-1] > unSortedValue)
            {
               anArray[scan] = anArray[scan-1];
               scan --;
            }
           // Drop in the unsorted value
           anArray[scan] = unSortedValue;
           
       }
         long endSort = System.nanoTime();  
              insertionSortDuration = endSort - startSort;
              System.out.println("NANOSECOND START: " + startSort);
              System.out.println("NANOSECOND END: " + endSort);
              System.out.println("This took " + insertionSortDuration + " nanoseconds");
        
    }
    /*
    Description: This method is the bubble sort method that allows us to sort our anArray in a way it gets the elements and compares
    them one by one from lowest to greatest.This method as well displays its sort time.
    
    no throws, int[] anArray parameter, no returns
    */
    public static void bubbleSort(int[] anArray)
    {
        //1.  create a long variable  called startSort, and another one called endSort
        //2.  assign  System.nanoTime()  to startSort
        //3.  copy the sorting algorithm from PowerPoint 
        //4.  after sort is over, assign System.nanoTime() to endSort
        //5.  Calculate selectionSortDuration = endSort - startSort

        long startSort = System.nanoTime();
        
        for (int last = anArray.length -1; last >= 1; last --)
        {
          // Move the largest entry in A[0…last] to A[last]
          for (int index = 0; index <= last-1; index++)
          {     
               //swap adjacent elements if necessary
                if (anArray[index] > anArray[index+1])
                {
                    int temp = anArray[index]; 
                    anArray[index] = anArray[index+1];
                    anArray[index + 1] = temp;
                }
          }
        }
       long endSort = System.nanoTime();  
              bubbleSortDuration = endSort - startSort;
              System.out.println("NANOSECOND START: " + startSort);
              System.out.println("NANOSECOND END: " + endSort);
              System.out.println("This took " + bubbleSortDuration + " nanoseconds");
    }
    
    /*
    Description:This method allows to compare the time of the sorting algorithms. And see which is faster
    no throws, params, or returns
    
    */
    public static void compareSortTimes()
    {
        //if statements to ask if selectionSortDuration > insertionSortDuration &&
        //                        selectionSortDuration > bubbleSortDuration
        //                        State that selection sort too the longest
        // else...
        
        System.out.println("SelectionSortDuration: " + selectionSortDuration);
        System.out.println("InsertionSortDuration: " + insertionSortDuration);
        System.out.println("BubbleSortDuration: " + bubbleSortDuration);
        
        if (selectionSortDuration > insertionSortDuration && selectionSortDuration > bubbleSortDuration){
            
             System.out.println("SelectionSort is faster");
        }
           
        else 
        {
            System.out.println("Another algorithm is faster");
        }
        
        if (selectionSortDuration < insertionSortDuration && selectionSortDuration < bubbleSortDuration){
            
            System.out.println("Bubble sort is the fastest");
        }
        else
        {
            System.out.println("Insertion sort is the fastest");
        }
        
         //if statements to ask if selectionSortDuration < insertionSortDuration &&
        //                        selectionSortDuration < bubbleSortDuration
        //                        State that selection sort too the shortest
        // else...
        
    }
    
    
}
